package com.example.altyazi

import android.content.Context

/**
 * Kalıcı çeviri hafızası.
 *
 * Bir kez çevrilen replik telefona yazılır. Aynı replik tekrar geçtiğinde
 * ne internet ne de jeton gerekir, anında ekrana gelir. Oyunu ikinci kez
 * oynarken veya aynı diziyi izlerken uygulama kendi kendine hızlanır.
 */
class TranslationStore(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("ceviri_hafizasi", Context.MODE_PRIVATE)

    fun get(english: String): String? {
        val key = key(english)
        if (key.isEmpty()) return null
        return sp.getString(key, null)
    }

    fun put(english: String, turkish: String) {
        val key = key(english)
        if (key.isEmpty() || turkish.isBlank()) return
        if (sp.all.size > MAX_ENTRIES) {
            // Hafıza şişerse sıfırlanır; yeniden dolması birkaç oturum sürer.
            sp.edit().clear().apply()
        }
        sp.edit().putString(key, turkish).apply()
    }

    fun count(): Int = sp.all.size

    fun clear() = sp.edit().clear().apply()

    private fun key(text: String): String =
        text.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim().take(200)

    companion object {
        private const val MAX_ENTRIES = 5000
    }
}
